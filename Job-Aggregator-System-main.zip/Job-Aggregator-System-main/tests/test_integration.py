"""Integration tests for scraper -> DB -> API flow"""
import pytest
import asyncio
from fastapi.testclient import TestClient
from app.main import app
from app.database import Base, engine, SessionLocal
from app.scraper.amazon_scraper import AmazonScraper
from app.schemas import JobCreate
from app import crud

client = TestClient(app)

@pytest.fixture(scope="module", autouse=True)
def setup_database():
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)

@pytest.mark.asyncio
async def test_scraper_and_api_flow():
    # Run scraper (fallback returns sample data)
    scraper = AmazonScraper()
    jobs = scraper.scrape_with_requests()
    db = SessionLocal()
    for job in jobs:
        crud.upsert_job(db, JobCreate(**job))
    db.close()

    # Check API returns jobs
    response = client.get("/api/jobs")
    assert response.status_code == 200
    data = response.json()
    assert data["total"] > 0
    assert isinstance(data["jobs"], list)
