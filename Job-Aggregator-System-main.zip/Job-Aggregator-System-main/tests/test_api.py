"""Test API endpoints"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from datetime import datetime

from app.main import app
from app.database import Base, get_db
from app.models import Job

# Create test database
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Override dependency
def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

# Create tables
Base.metadata.create_all(bind=engine)

client = TestClient(app)

def test_root():
    response = client.get("/")
    assert response.status_code == 200
    assert "message" in response.json()

def test_create_and_get_job():
    job_data = {
        "job_id": "TEST_API_001",
        "company_name": "TestCorp",
        "job_title": "API Engineer",
        "job_location": "Remote",
        "job_url": "https://example.com/job",
        "job_description": "API testing role",
    }
    response = client.post("/api/jobs", json=job_data)
    assert response.status_code == 200
    created_job = response.json()
    assert created_job["company_name"] == "TestCorp"

    # Get job by id
    job_id = created_job["id"]
    response = client.get(f"/api/jobs/{job_id}")
    assert response.status_code == 200
    fetched_job = response.json()
    assert fetched_job["job_id"] == "TEST_API_001"

def test_get_jobs_list():
    response = client.get("/api/jobs?page=1&page_size=10")
    assert response.status_code == 200
    result = response.json()
    assert "jobs" in result
    assert "total" in result
