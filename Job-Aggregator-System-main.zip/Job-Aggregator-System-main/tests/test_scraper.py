"""Test scraper modules"""
import pytest
import asyncio
from datetime import datetime
from unittest.mock import Mock, patch, AsyncMock

from app.scraper.amazon_scraper import AmazonScraper
from app.scraper.microsoft_scraper import MicrosoftScraper
from app.schemas import JobCreate

@pytest.fixture
def amazon_scraper():
    return AmazonScraper()

@pytest.fixture
def microsoft_scraper():
    return MicrosoftScraper()

def test_amazon_scraper_initialization(amazon_scraper):
    """Test Amazon scraper initialization"""
    assert amazon_scraper.COMPANY_NAME == "Amazon"
    assert amazon_scraper.BASE_URL == "https://www.amazon.jobs/en/search"
    assert amazon_scraper.session is not None

def test_microsoft_scraper_initialization(microsoft_scraper):
    """Test Microsoft scraper initialization"""
    assert microsoft_scraper.COMPANY_NAME == "Microsoft"
    assert "microsoft.com" in microsoft_scraper.BASE_URL
    assert microsoft_scraper.session is not None

def test_scrape_with_requests_amazon(amazon_scraper):
    """Test fallback scraper for Amazon"""
    jobs = amazon_scraper.scrape_with_requests()
    
    assert isinstance(jobs, list)
    assert len(jobs) > 0
    
    for job in jobs:
        assert 'job_id' in job
        assert 'company_name' in job
        assert job['company_name'] == 'Amazon'
        assert 'job_title' in job
        assert 'job_url' in job

def test_scrape_with_requests_microsoft(microsoft_scraper):
    """Test fallback scraper for Microsoft"""
    jobs = microsoft_scraper.scrape_with_requests()
    
    assert isinstance(jobs, list)
    assert len(jobs) > 0
    
    for job in jobs:
        assert 'job_id' in job
        assert 'company_name' in job
        assert job['company_name'] == 'Microsoft'
        assert 'job_title' in job
        assert 'job_url' in job

def test_job_data_validation():
    """Test that scraped data can be validated with JobCreate schema"""
    sample_job = {
        'job_id': 'TEST_001',
        'company_name': 'Test Company',
        'job_title': 'Test Engineer',
        'job_location': 'Test Location',
        'job_url': 'https://example.com/job',
        'job_description': 'Test description',
        'posted_date': datetime.utcnow()
    }
    
    # This should not raise an exception
    job = JobCreate(**sample_job)
    assert job.job_id == 'TEST_001'
    assert job.company_name == 'Test Company'

@pytest.mark.asyncio
async def test_parse_job_tile_amazon(amazon_scraper):
    """Test parsing of job tile for Amazon"""
    # Create mock HTML element
    mock_tile = Mock()
    mock_title = Mock()
    mock_title.get_text.return_value = "Software Engineer"
    mock_link = Mock()
    mock_link.get.return_value = "/jobs/123"
    mock_location = Mock()
    mock_location.get_text.return_value = "Seattle, WA"
    
    mock_tile.find.side_effect = lambda *args, **kwargs: {
        ('h3', {'class': 'job-title'}): mock_title,
        ('a', {'class': 'job-link'}): mock_link,
        ('p', {'class': 'location-and-id'}): mock_location
    }.get((args[0], kwargs.get('class_')))
    
    job = amazon_scraper._parse_job_tile(mock_tile)
    
    assert job is not None
    assert job['job_title'] == "Software Engineer"
    assert job['job_location'] == "Seattle, WA"
    assert job['company_name'] == "Amazon"

@pytest.mark.asyncio
async def test_scrape_and_save_error_handling(amazon_scraper):
    """Test error handling in scrape_and_save"""
    with patch.object(amazon_scraper, 'scrape_with_playwright', side_effect=Exception("Test error")):
        with patch.object(amazon_scraper, 'scrape_with_requests', return_value=[]):
            count = await amazon_scraper.scrape_and_save()
            assert count == 0
