# Job Aggregator System

A full-stack project that **scrapes job postings** from company career pages (e.g., Amazon, Microsoft), **stores them in a database**, and serves them via a **REST API** and a **web dashboard**.

> Built to demonstrate an end-to-end ETL/data product: scraping → normalization → persistence → API → UI, with tests and Docker.

---

## Table of Contents
- [Features](#features)
- [Architecture](#architecture)
- [Project Structure](#project-structure)
- [Tech Stack](#tech-stack)
- [Prerequisites](#prerequisites)
- [Quickstart (Local)](#quickstart-local)
- [Environment & Config](#environment--config)
- [Database Schema](#database-schema)
- [API Reference](#api-reference)
- [Running Scrapers](#running-scrapers)
- [Docker](#docker)
- [Testing](#testing)
- [Troubleshooting](#troubleshooting)
- [Roadmap / Future Scope](#roadmap--future-scope)
- [License](#license)

---

## Features
- **Scraper Engine** using Playwright + Requests/BeautifulSoup (fallback) for dynamic/static pages.
- **Data normalization** into a single `jobs` table (unique on `job_id+company_name`).
- **Database layer** with SQLAlchemy ORM (SQLite by default; MySQL/Postgres ready).
- **REST API** with FastAPI + Pydantic schemas (pagination, filtering, search).
- **Dashboard UI** (Jinja2 + Bootstrap) to browse/search jobs.
- **Containerized** with Docker & docker-compose.
- **Tests** (pytest) covering scraper, API, and simple integration.

---

## Architecture

```
+------------------+      +------------------+      +-----------------+      +--------------------+
|  Scraper Engine  | ---> |  Normalization   | ---> |   Database      | ---> |  REST API + UI     |
|  (Playwright/BS) |      |  (Pydantic/ETL)  |      | (SQLAlchemy)    |      | (FastAPI + Jinja2) |
+------------------+      +------------------+      +-----------------+      +--------------------+
         |                                                                                 |
         +------------------------------------------- Tests (pytest) ----------------------+
```

---

## Project Structure

```
job-aggregator-system/
├── app/
│   ├── __init__.py
│   ├── main.py                 # FastAPI app & dashboard mount
│   ├── config.py               # env/config, DATABASE_URL
│   ├── database.py             # engine, session, Base
│   ├── models.py               # SQLAlchemy models
│   ├── schemas.py              # Pydantic schemas
│   ├── crud.py                 # DB CRUD helpers (upsert, list, get)
│   ├── api/
│   │   ├── __init__.py
│   │   └── routes.py           # /api endpoints
│   ├── scraper/
│   │   ├── __init__.py
│   │   ├── amazon_scraper.py   # Amazon careers scraper
│   │   └── microsoft_scraper.py# Microsoft careers scraper
│   └── dashboard/
│       ├── __init__.py
│       ├── routes.py           # /dashboard routes
│       └── templates/
│           ├── base.html
│           └── jobs.html
├── tests/
│   ├── test_scraper.py
│   ├── test_api.py
│   └── test_integration.py
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── README.md
```

---

## Tech Stack
- **Language**: Python 3.11
- **Backend**: FastAPI, Uvicorn
- **ORM/DB**: SQLAlchemy, SQLite (default). MySQL/Postgres supported via `DATABASE_URL`.
- **Scraping**: Playwright, Requests, BeautifulSoup4
- **UI**: Jinja2, Bootstrap
- **Testing**: pytest, httpx
- **DevOps**: Docker, docker-compose

---

## Prerequisites
- Python **3.10+** (3.11 recommended)
- pip
- (For Playwright) one-time: `playwright install`
- Optional: Docker & docker-compose

---

## Quickstart (Local)

```bash
git clone <your-repo-url>.git
cd job-aggregator-system

# 1) Python deps
pip install -r requirements.txt

# 2) Playwright browsers (Chromium/Firefox/WebKit)
playwright install

# 3) Run API + Dashboard
uvicorn app.main:app --reload
```

- API docs → http://127.0.0.1:8000/docs  
- Dashboard → http://127.0.0.1:8000/dashboard  

> **Tip:** The default database is `sqlite:///./job_aggregator.db`. Change via `DATABASE_URL` env var.

---

## Environment & Config

The app reads these from environment variables (see `app/config.py`):

- `DATABASE_URL` (default: `sqlite:///./job_aggregator.db`)  
  - Examples:  
    - SQLite: `sqlite:///./job_aggregator.db`  
    - MySQL: `mysql+pymysql://user:pass@localhost/jobdb`  
    - Postgres: `postgresql+psycopg2://user:pass@localhost/jobdb`
- `PLAYWRIGHT_HEADLESS` (default: `true`): `true|false`
- `LOG_LEVEL` (default: `INFO`)

---

## Database Schema

**Table: `jobs`**
- `id` (PK, int, autoincrement)
- `job_id` (str, required) – vendor’s job reference
- `company_name` (str, required)
- `job_title` (str)
- `job_location` (str)
- `job_url` (str)
- `job_description` (str, optional)
- `posted_date` (datetime, optional)
- `last_updated` (datetime, auto-updated)

**Uniqueness**: composite uniqueness by (`job_id`, `company_name`).

---

## API Reference

Base URL: `http://127.0.0.1:8000` (see `/docs` for OpenAPI)

### List Jobs
`GET /api/jobs`
- Query params:
  - `q` (search title/desc)
  - `company`
  - `location`
  - `page` (default: 1)
  - `page_size` (default: 10)

Response:
```json
{ "jobs": [ { ...job }, ... ], "total": 123, "page": 1, "page_size": 10 }
```

### Get Job by ID
`GET /api/jobs/{id}`

### Create/Upsert Job
`POST /api/jobs`
```json
{
  "job_id": "AMZ-123",
  "company_name": "Amazon",
  "job_title": "Software Engineer",
  "job_location": "Hyderabad, IN",
  "job_url": "https://example.com/job",
  "job_description": "Build services..."
}
```

---

## Running Scrapers

```python
from app.database import SessionLocal
from app.schemas import JobCreate
from app.scraper.amazon_scraper import AmazonScraper
from app.scraper.microsoft_scraper import MicrosoftScraper
from app import crud

db = SessionLocal()

for scraper_cls in (AmazonScraper, MicrosoftScraper):
    scraper = scraper_cls()
    jobs = scraper.scrape_with_requests()
    for j in jobs:
        crud.upsert_job(db, JobCreate(**j))

db.close()
```

---

## Docker

```bash
docker-compose up --build
```

- App: http://localhost:8000  

Override DB in `docker-compose.yml` if needed:
```yaml
environment:
  - DATABASE_URL=sqlite:///./job_aggregator.db
```

---

## Testing

```bash
pytest -q
```

- `tests/test_scraper.py` – scraper contract  
- `tests/test_api.py` – API endpoints  
- `tests/test_integration.py` – end-to-end (scraper → DB → API)  

---

## Troubleshooting
- **Playwright missing browsers**: run `playwright install`  
- **SQLite locked**: avoid multiple writers; stop other processes or switch DB.  
- **Import errors**: run from project root (`job-aggregator-system/`).  

---

## Roadmap / Future Scope
- Add more company scrapers
- User auth + saved searches + alerts
- Cloud deployment (AWS/GCP) with CI/CD
- Redis caching for hot queries
- Advanced search (Elasticsearch/OpenSearch)

---

## License
MIT (or choose your preferred license).
```

