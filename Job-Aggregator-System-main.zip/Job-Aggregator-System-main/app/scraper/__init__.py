"""Scraper module"""
from .amazon_scraper import AmazonScraper
from .microsoft_scraper import MicrosoftScraper

__all__ = ["AmazonScraper", "MicrosoftScraper"]
