"""Amazon jobs scraper"""
import asyncio
import logging
from datetime import datetime
from typing import List, Dict, Optional
import hashlib
import json

from playwright.async_api import async_playwright, Page
from bs4 import BeautifulSoup
import requests

from app.schemas import JobCreate
from app.database import SessionLocal
from app.crud import upsert_job

logger = logging.getLogger(__name__)

class AmazonScraper:
    """Scraper for Amazon careers page"""
    
    BASE_URL = "https://www.amazon.jobs/en/search"
    COMPANY_NAME = "Amazon"
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    async def scrape_with_playwright(self) -> List[Dict]:
        """Scrape Amazon jobs using Playwright for dynamic content"""
        jobs = []
        
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()
            
            try:
                # Navigate to Amazon jobs page
                await page.goto(self.BASE_URL, wait_until='networkidle')
                await page.wait_for_selector('.job-tile', timeout=10000)
                
                # Get page content
                content = await page.content()
                soup = BeautifulSoup(content, 'html.parser')
                
                # Parse job listings
                job_tiles = soup.find_all('div', class_='job-tile')[:20]  # Limit to 20 jobs
                
                for tile in job_tiles:
                    try:
                        job = self._parse_job_tile(tile)
                        if job:
                            jobs.append(job)
                    except Exception as e:
                        logger.error(f"Error parsing job tile: {e}")
                
            except Exception as e:
                logger.error(f"Error scraping Amazon jobs: {e}")
            finally:
                await browser.close()
        
        return jobs
    
    def _parse_job_tile(self, tile) -> Optional[Dict]:
        """Parse individual job tile"""
        try:
            # Extract job details
            title_elem = tile.find('h3', class_='job-title')
            location_elem = tile.find('p', class_='location-and-id')
            link_elem = tile.find('a', class_='job-link')
            
            if not title_elem or not link_elem:
                return None
            
            job_title = title_elem.get_text(strip=True)
            job_url = f"https://www.amazon.jobs{link_elem.get('href', '')}"
            job_location = location_elem.get_text(strip=True) if location_elem else "Remote"
            
            # Generate unique job ID
            job_id = f"AMZN_{hashlib.md5(job_url.encode()).hexdigest()[:8]}"
            
            return {
                'job_id': job_id,
                'company_name': self.COMPANY_NAME,
                'job_title': job_title,
                'job_location': job_location,
                'job_url': job_url,
                'job_description': f"Job at {self.COMPANY_NAME}",
                'posted_date': datetime.utcnow()
            }
        except Exception as e:
            logger.error(f"Error parsing job tile: {e}")
            return None
    
    def scrape_with_requests(self) -> List[Dict]:
        """Fallback scraper using requests (for static content)"""
        jobs = []
        
        try:
            # This is a simplified version - real Amazon site requires more complex handling
            # For demo purposes, we'll return sample data
            sample_jobs = [
                {
                    'job_id': f'AMZN_001',
                    'company_name': self.COMPANY_NAME,
                    'job_title': 'Software Development Engineer',
                    'job_location': 'Seattle, WA',
                    'job_url': 'https://www.amazon.jobs/en/jobs/example1',
                    'job_description': 'Build scalable systems at Amazon',
                    'posted_date': datetime.utcnow()
                },
                {
                    'job_id': f'AMZN_002',
                    'company_name': self.COMPANY_NAME,
                    'job_title': 'Senior Data Scientist',
                    'job_location': 'New York, NY',
                    'job_url': 'https://www.amazon.jobs/en/jobs/example2',
                    'job_description': 'Drive data insights at Amazon',
                    'posted_date': datetime.utcnow()
                }
            ]
            return sample_jobs
        except Exception as e:
            logger.error(f"Error in fallback scraper: {e}")
            return []
    
    async def scrape_and_save(self) -> int:
        """Scrape jobs and save to database"""
        try:
            # Try Playwright first, fallback to requests
            try:
                jobs = await self.scrape_with_playwright()
            except Exception:
                logger.warning("Playwright failed, using fallback scraper")
                jobs = self.scrape_with_requests()
            
            # Save jobs to database
            db = SessionLocal()
            saved_count = 0
            
            for job_data in jobs:
                try:
                    job = JobCreate(**job_data)
                    upsert_job(db, job)
                    saved_count += 1
                except Exception as e:
                    logger.error(f"Error saving job: {e}")
            
            db.close()
            logger.info(f"Saved {saved_count} Amazon jobs")
            return saved_count
            
        except Exception as e:
            logger.error(f"Error in scrape_and_save: {e}")
            return 0

# Scraper instance
amazon_scraper = AmazonScraper()
