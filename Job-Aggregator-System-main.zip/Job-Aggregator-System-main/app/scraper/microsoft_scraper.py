"""Microsoft jobs scraper"""
import asyncio
import logging
from datetime import datetime
from typing import List, Dict, Optional
import hashlib
import json

from playwright.async_api import async_playwright
from bs4 import BeautifulSoup
import requests

from app.schemas import JobCreate
from app.database import SessionLocal
from app.crud import upsert_job

logger = logging.getLogger(__name__)

class MicrosoftScraper:
    """Scraper for Microsoft careers page"""
    
    BASE_URL = "https://careers.microsoft.com/professionals/us/en/search-results"
    COMPANY_NAME = "Microsoft"
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    async def scrape_with_playwright(self) -> List[Dict]:
        """Scrape Microsoft jobs using Playwright for dynamic content"""
        jobs = []
        
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()
            
            try:
                # Navigate to Microsoft careers page
                await page.goto(self.BASE_URL, wait_until='networkidle')
                await page.wait_for_selector('.job-card', timeout=10000)
                
                # Get page content
                content = await page.content()
                soup = BeautifulSoup(content, 'html.parser')
                
                # Parse job listings
                job_cards = soup.find_all('div', class_='job-card')[:20]  # Limit to 20 jobs
                
                for card in job_cards:
                    try:
                        job = self._parse_job_card(card)
                        if job:
                            jobs.append(job)
                    except Exception as e:
                        logger.error(f"Error parsing job card: {e}")
                
            except Exception as e:
                logger.error(f"Error scraping Microsoft jobs: {e}")
            finally:
                await browser.close()
        
        return jobs
    
    def _parse_job_card(self, card) -> Optional[Dict]:
        """Parse individual job card"""
        try:
            # Extract job details (structure based on typical Microsoft careers page)
            title_elem = card.find('h2') or card.find('h3')
            location_elem = card.find('span', class_='job-location')
            link_elem = card.find('a')
            
            if not title_elem or not link_elem:
                return None
            
            job_title = title_elem.get_text(strip=True)
            job_url = link_elem.get('href', '')
            if not job_url.startswith('http'):
                job_url = f"https://careers.microsoft.com{job_url}"
            
            job_location = location_elem.get_text(strip=True) if location_elem else "Redmond, WA"
            
            # Generate unique job ID
            job_id = f"MSFT_{hashlib.md5(job_url.encode()).hexdigest()[:8]}"
            
            return {
                'job_id': job_id,
                'company_name': self.COMPANY_NAME,
                'job_title': job_title,
                'job_location': job_location,
                'job_url': job_url,
                'job_description': f"Opportunity at {self.COMPANY_NAME}",
                'posted_date': datetime.utcnow()
            }
        except Exception as e:
            logger.error(f"Error parsing job card: {e}")
            return None
    
    def scrape_with_requests(self) -> List[Dict]:
        """Fallback scraper using requests (for static content)"""
        jobs = []
        
        try:
            # This is a simplified version - real Microsoft site requires more complex handling
            # For demo purposes, we'll return sample data
            sample_jobs = [
                {
                    'job_id': f'MSFT_001',
                    'company_name': self.COMPANY_NAME,
                    'job_title': 'Principal Software Engineer',
                    'job_location': 'Redmond, WA',
                    'job_url': 'https://careers.microsoft.com/job/example1',
                    'job_description': 'Lead engineering teams at Microsoft',
                    'posted_date': datetime.utcnow()
                },
                {
                    'job_id': f'MSFT_002',
                    'company_name': self.COMPANY_NAME,
                    'job_title': 'Cloud Solution Architect',
                    'job_location': 'Austin, TX',
                    'job_url': 'https://careers.microsoft.com/job/example2',
                    'job_description': 'Design Azure solutions for enterprise clients',
                    'posted_date': datetime.utcnow()
                },
                {
                    'job_id': f'MSFT_003',
                    'company_name': self.COMPANY_NAME,
                    'job_title': 'AI Research Scientist',
                    'job_location': 'Cambridge, MA',
                    'job_url': 'https://careers.microsoft.com/job/example3',
                    'job_description': 'Advance AI research at Microsoft Research',
                    'posted_date': datetime.utcnow()
                }
            ]
            return sample_jobs
        except Exception as e:
            logger.error(f"Error in fallback scraper: {e}")
            return []
    
    async def scrape_and_save(self) -> int:
        """Scrape jobs and save to database"""
        try:
            # Try Playwright first, fallback to requests
            try:
                jobs = await self.scrape_with_playwright()
            except Exception:
                logger.warning("Playwright failed, using fallback scraper")
                jobs = self.scrape_with_requests()
            
            # Save jobs to database
            db = SessionLocal()
            saved_count = 0
            
            for job_data in jobs:
                try:
                    job = JobCreate(**job_data)
                    upsert_job(db, job)
                    saved_count += 1
                except Exception as e:
                    logger.error(f"Error saving job: {e}")
            
            db.close()
            logger.info(f"Saved {saved_count} Microsoft jobs")
            return saved_count
            
        except Exception as e:
            logger.error(f"Error in scrape_and_save: {e}")
            return 0

# Scraper instance
microsoft_scraper = MicrosoftScraper()
