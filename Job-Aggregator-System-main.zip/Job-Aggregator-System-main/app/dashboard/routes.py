"""Dashboard routes"""
from fastapi import APIRouter, Request, Depends, Query
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from typing import Optional
import math
import os

from app.database import get_db
from app import crud
from app.config import settings

router = APIRouter()

# Setup templates
templates_dir = os.path.join(os.path.dirname(__file__), "templates")
templates = Jinja2Templates(directory=templates_dir)

@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard(
    request: Request,
    company: Optional[str] = Query(None),
    location: Optional[str] = Query(None),
    keyword: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    db: Session = Depends(get_db)
):
    """Render dashboard with job listings"""
    page_size = 10
    skip = (page - 1) * page_size
    
    # Get jobs with filters
    jobs = crud.get_jobs(
        db=db,
        skip=skip,
        limit=page_size,
        company=company,
        location=location,
        keyword=keyword
    )
    
    # Get total count
    total = crud.get_total_jobs_count(
        db=db,
        company=company,
        location=location,
        keyword=keyword
    )
    
    total_pages = math.ceil(total / page_size)
    
    # Get companies and locations for filters
    companies = db.query(crud.Job.company_name).distinct().all()
    locations = db.query(crud.Job.job_location).distinct().filter(
        crud.Job.job_location.isnot(None)
    ).all()
    
    # Get stats
    stats = {
        'total_jobs': db.query(crud.Job).count(),
        'total_companies': len(companies),
        'total_locations': len(locations)
    }
    
    return templates.TemplateResponse(
        "jobs.html",
        {
            "request": request,
            "jobs": jobs,
            "total": total,
            "page": page,
            "total_pages": total_pages,
            "companies": [c[0] for c in companies],
            "locations": [l[0] for l in locations],
            "current_company": company,
            "current_location": location,
            "current_keyword": keyword,
            "stats": stats
        }
    )

@router.get("/scrape", response_class=HTMLResponse)
async def trigger_scrape(request: Request):
    """Trigger manual scraping"""
    from app.scraper.amazon_scraper import amazon_scraper
    from app.scraper.microsoft_scraper import microsoft_scraper
    
    # Run scrapers
    amazon_count = await amazon_scraper.scrape_and_save()
    microsoft_count = await microsoft_scraper.scrape_and_save()
    
    return templates.TemplateResponse(
        "base.html",
        {
            "request": request,
            "message": f"Scraping complete! Added {amazon_count} Amazon jobs and {microsoft_count} Microsoft jobs.",
            "redirect_url": "/dashboard"
        }
    )
