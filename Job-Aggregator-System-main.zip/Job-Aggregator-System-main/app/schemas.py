"""Pydantic schemas for request/response validation"""
from pydantic import BaseModel, HttpUrl, Field
from datetime import datetime
from typing import Optional, List

class JobBase(BaseModel):
    """Base job schema"""
    job_id: str = Field(..., description="Unique job identifier")
    company_name: str = Field(..., description="Company name")
    job_title: str = Field(..., description="Job title")
    job_location: Optional[str] = Field(None, description="Job location")
    job_url: str = Field(..., description="Job posting URL")
    job_description: Optional[str] = Field(None, description="Job description")
    posted_date: Optional[datetime] = Field(None, description="Date job was posted")

class JobCreate(JobBase):
    """Schema for creating a job"""
    pass

class JobUpdate(BaseModel):
    """Schema for updating a job"""
    job_title: Optional[str] = None
    job_location: Optional[str] = None
    job_description: Optional[str] = None
    posted_date: Optional[datetime] = None

class JobResponse(JobBase):
    """Schema for job response"""
    id: int
    last_updated: datetime
    created_at: datetime
    
    class Config:
        from_attributes = True

class JobListResponse(BaseModel):
    """Schema for paginated job list response"""
    jobs: List[JobResponse]
    total: int
    page: int
    page_size: int
    total_pages: int

class SearchParams(BaseModel):
    """Schema for search parameters"""
    keyword: Optional[str] = None
    company: Optional[str] = None
    location: Optional[str] = None
    page: int = 1
    page_size: int = 20
