"""CRUD operations for database"""
from sqlalchemy.orm import Session
from sqlalchemy import or_, and_, func
from typing import Optional, List
from datetime import datetime
import logging

from app.models import Job
from app.schemas import JobCreate, JobUpdate

logger = logging.getLogger(__name__)

def create_job(db: Session, job: JobCreate) -> Job:
    """Create a new job posting"""
    db_job = Job(**job.dict())
    db.add(db_job)
    db.commit()
    db.refresh(db_job)
    logger.info(f"Created job: {db_job.job_title} at {db_job.company_name}")
    return db_job

def get_job(db: Session, job_id: int) -> Optional[Job]:
    """Get a job by ID"""
    return db.query(Job).filter(Job.id == job_id).first()

def get_job_by_job_id(db: Session, job_id: str) -> Optional[Job]:
    """Get a job by job_id (unique identifier)"""
    return db.query(Job).filter(Job.job_id == job_id).first()

def get_jobs(
    db: Session,
    skip: int = 0,
    limit: int = 100,
    company: Optional[str] = None,
    location: Optional[str] = None,
    keyword: Optional[str] = None
) -> List[Job]:
    """Get jobs with optional filters"""
    query = db.query(Job)
    
    if company:
        query = query.filter(Job.company_name.ilike(f"%{company}%"))
    
    if location:
        query = query.filter(Job.job_location.ilike(f"%{location}%"))
    
    if keyword:
        query = query.filter(
            or_(
                Job.job_title.ilike(f"%{keyword}%"),
                Job.job_description.ilike(f"%{keyword}%")
            )
        )
    
    return query.order_by(Job.created_at.desc()).offset(skip).limit(limit).all()

def get_total_jobs_count(
    db: Session,
    company: Optional[str] = None,
    location: Optional[str] = None,
    keyword: Optional[str] = None
) -> int:
    """Get total count of jobs with filters"""
    query = db.query(func.count(Job.id))
    
    if company:
        query = query.filter(Job.company_name.ilike(f"%{company}%"))
    
    if location:
        query = query.filter(Job.job_location.ilike(f"%{location}%"))
    
    if keyword:
        query = query.filter(
            or_(
                Job.job_title.ilike(f"%{keyword}%"),
                Job.job_description.ilike(f"%{keyword}%")
            )
        )
    
    return query.scalar()

def update_job(db: Session, job_id: int, job_update: JobUpdate) -> Optional[Job]:
    """Update a job posting"""
    db_job = db.query(Job).filter(Job.id == job_id).first()
    if db_job:
        update_data = job_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_job, field, value)
        db_job.last_updated = datetime.utcnow()
        db.commit()
        db.refresh(db_job)
        logger.info(f"Updated job: {db_job.job_title}")
    return db_job

def delete_job(db: Session, job_id: int) -> bool:
    """Delete a job posting"""
    db_job = db.query(Job).filter(Job.id == job_id).first()
    if db_job:
        db.delete(db_job)
        db.commit()
        logger.info(f"Deleted job: {db_job.job_title}")
        return True
    return False

def upsert_job(db: Session, job: JobCreate) -> Job:
    """Insert or update a job based on job_id"""
    db_job = get_job_by_job_id(db, job.job_id)
    if db_job:
        # Update existing job
        for field, value in job.dict().items():
            setattr(db_job, field, value)
        db_job.last_updated = datetime.utcnow()
        db.commit()
        db.refresh(db_job)
        logger.info(f"Updated existing job: {db_job.job_title}")
    else:
        # Create new job
        db_job = create_job(db, job)
    return db_job
