"""API routes"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
import math

from app.database import get_db
from app.schemas import JobResponse, JobListResponse, JobCreate, JobUpdate
from app import crud
from app.config import settings

router = APIRouter()

@router.get("/jobs", response_model=JobListResponse)
async def get_jobs(
    company: Optional[str] = Query(None, description="Filter by company name"),
    location: Optional[str] = Query(None, description="Filter by location"),
    keyword: Optional[str] = Query(None, description="Search keyword"),
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(settings.DEFAULT_PAGE_SIZE, ge=1, le=settings.MAX_PAGE_SIZE),
    db: Session = Depends(get_db)
):
    """Get all jobs with optional filters and pagination"""
    skip = (page - 1) * page_size
    
    jobs = crud.get_jobs(
        db=db,
        skip=skip,
        limit=page_size,
        company=company,
        location=location,
        keyword=keyword
    )
    
    total = crud.get_total_jobs_count(
        db=db,
        company=company,
        location=location,
        keyword=keyword
    )
    
    total_pages = math.ceil(total / page_size)
    
    return JobListResponse(
        jobs=jobs,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages
    )

@router.get("/jobs/{job_id}", response_model=JobResponse)
async def get_job(job_id: int, db: Session = Depends(get_db)):
    """Get a specific job by ID"""
    job = crud.get_job(db, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job

@router.post("/jobs", response_model=JobResponse)
async def create_job(job: JobCreate, db: Session = Depends(get_db)):
    """Create a new job posting"""
    # Check if job already exists
    existing_job = crud.get_job_by_job_id(db, job.job_id)
    if existing_job:
        raise HTTPException(status_code=400, detail="Job already exists")
    
    return crud.create_job(db, job)

@router.put("/jobs/{job_id}", response_model=JobResponse)
async def update_job(
    job_id: int,
    job_update: JobUpdate,
    db: Session = Depends(get_db)
):
    """Update a job posting"""
    job = crud.update_job(db, job_id, job_update)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job

@router.delete("/jobs/{job_id}")
async def delete_job(job_id: int, db: Session = Depends(get_db)):
    """Delete a job posting"""
    success = crud.delete_job(db, job_id)
    if not success:
        raise HTTPException(status_code=404, detail="Job not found")
    return {"message": "Job deleted successfully"}

@router.get("/companies")
async def get_companies(db: Session = Depends(get_db)):
    """Get list of all companies"""
    companies = db.query(crud.Job.company_name).distinct().all()
    return {"companies": [c[0] for c in companies]}

@router.get("/locations")
async def get_locations(db: Session = Depends(get_db)):
    """Get list of all locations"""
    locations = db.query(crud.Job.job_location).distinct().filter(
        crud.Job.job_location.isnot(None)
    ).all()
    return {"locations": [l[0] for l in locations]}

@router.get("/stats")
async def get_stats(db: Session = Depends(get_db)):
    """Get statistics about jobs"""
    total_jobs = db.query(crud.Job).count()
    companies = db.query(crud.Job.company_name).distinct().count()
    locations = db.query(crud.Job.job_location).distinct().filter(
        crud.Job.job_location.isnot(None)
    ).count()
    
    return {
        "total_jobs": total_jobs,
        "total_companies": companies,
        "total_locations": locations
    }
