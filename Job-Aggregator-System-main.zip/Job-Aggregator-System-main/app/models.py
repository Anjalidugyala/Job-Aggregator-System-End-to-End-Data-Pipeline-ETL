"""SQLAlchemy database models"""
from sqlalchemy import Column, Integer, String, DateTime, Text, Index
from sqlalchemy.sql import func
from app.database import Base

class Job(Base):
    """Job posting model"""
    __tablename__ = "jobs"
    
    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(String(100), unique=True, index=True, nullable=False)
    company_name = Column(String(100), nullable=False, index=True)
    job_title = Column(String(200), nullable=False)
    job_location = Column(String(200), nullable=True)
    job_url = Column(Text, nullable=False)
    job_description = Column(Text, nullable=True)
    posted_date = Column(DateTime, nullable=True)
    last_updated = Column(DateTime, default=func.now(), onupdate=func.now())
    created_at = Column(DateTime, default=func.now())
    
    # Add composite index for common queries
    __table_args__ = (
        Index('idx_company_location', 'company_name', 'job_location'),
        Index('idx_title_search', 'job_title'),
    )
    
    def __repr__(self):
        return f"<Job(id={self.id}, title='{self.job_title}', company='{self.company_name}')>"
